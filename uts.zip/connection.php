<?php
$conn = new mysqli("localhost","root","mysql.ganezo","uts_quiz");